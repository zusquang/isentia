require('../libs/lib.define');

define( 'GET_PHOTOS', '/api/photos', this );
define( 'GET_PHOTOS_BY_TAGS', '/api/photos/tags/:tags', this ); 