(function() {
	'use strict';
	var angular = require('angular');

	angular.module('photo.controller', []).controller('PhotoController', photoController);

 	function photoController() {
     
	}
})();
